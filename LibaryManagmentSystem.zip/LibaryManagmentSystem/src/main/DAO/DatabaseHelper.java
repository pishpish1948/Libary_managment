/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 44794
 */
import java.sql.*;
public class DatabaseHelper {
    public static Connection getConnection(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            
           Connection con = DriverManager.getConnection("");
           System.err.println("Connection done");
            return con;
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Connection error");
}
        return null;
    }
}
