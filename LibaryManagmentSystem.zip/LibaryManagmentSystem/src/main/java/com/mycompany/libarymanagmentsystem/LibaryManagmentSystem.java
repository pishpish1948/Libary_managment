/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.libarymanagmentsystem;

/**
 *
 * @author 44794
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LibaryManagmentSystem extends JFrame {
    JMenu menu;
    JMenu edit;
    JMenuItem logout,exit,cut,copy,paste;
    LibaryManagmentSystem() {
        JMenuBar m = new JMenuBar();
        menu = new JMenu("File");
        logout = new JMenuItem("Logout");
        exit = new JMenuItem("Exit");
        menu.add(logout);
        menu.add(exit);
        m.add(menu);
        edit = new JMenu("Edit");
        cut = new JMenu("cut");
        copy = new JMenu("copy");
        paste = new JMenu("paste");
        edit.add(cut);
        edit.add(copy);
        edit.add(paste);
        m.add(edit);
        
        // Set up the main frame
        setTitle("Main Menu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 500);
        setLayout(null);
        add(m);
        setJMenuBar(m);
        // Title label
        JLabel titleLabel = new JLabel("Library Management System", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 24));
        titleLabel.setForeground(Color.PINK);
        titleLabel.setBounds(100, 10, 400, 40);
        add(titleLabel);

        // Welcome label
        JLabel welcomeLabel = new JLabel("Welcome to Library", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Serif", Font.PLAIN, 14));
        welcomeLabel.setForeground(Color.PINK);
        welcomeLabel.setBounds(450, 10, 140, 40);
        add(welcomeLabel);

        // Operation panel
        JPanel operationPanel = new JPanel();
        operationPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.GREEN), "Operation", 0, 0, new Font("Serif", Font.BOLD, 18), Color.BLUE));
        operationPanel.setBounds(50, 60, 500, 150);
        operationPanel.setLayout(new GridLayout(1, 3, 10, 10));
        add(operationPanel);

        JButton newBookButton = new JButton("New Book");
        newBookButton.setBackground(Color.ORANGE);
        operationPanel.add(newBookButton);
        newBookButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                NewBookActionPerformed(e);
            }
        });
        
        JButton statisticsButton = new JButton("Statistics");
        statisticsButton.setBackground(Color.ORANGE);
        operationPanel.add(statisticsButton);
        statisticsButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                StatisticsActionPerformed(e);
            }
        });

        JButton newStudentButton = new JButton("New Student");
        newStudentButton.setBackground(Color.ORANGE);
        operationPanel.add(newStudentButton);
        newStudentButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                NewStudentActionPerformed(e);
            }
        });

        // Action panel
        JPanel actionPanel = new JPanel();
        actionPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.GREEN), "Action", 0, 0, new Font("Serif", Font.BOLD, 18), Color.RED));
        actionPanel.setBounds(50, 230, 500, 150);
        actionPanel.setLayout(new GridLayout(1, 2, 10, 10));
        add(actionPanel);

        JButton issueBookButton = new JButton("Issue Book");
        issueBookButton.setBackground(Color.YELLOW);
        actionPanel.add(issueBookButton);
        issueBookButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                IssueBookActionPerformed(e);
            }
        });
        JButton returnBookButton = new JButton("Return Book");
        returnBookButton.setBackground(Color.YELLOW);
        actionPanel.add(returnBookButton);
        returnBookButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
               ReturnBookActionPerformed(e);
            }
        });
        // Set frame visibility
        setVisible(true);
    }
    void NewBookActionPerformed(ActionEvent e){
        NewBook ob = new NewBook();
        ob.setVisible(true);
        this.dispose();
        
    }
    void IssueBookActionPerformed(ActionEvent e){
        IssueBook ob = new IssueBook();
        ob.setVisible(true);
        this.dispose();
        
    }
    void StatisticsActionPerformed(ActionEvent e){
        Statistics ob = new Statistics();
        ob.setVisible(true);
        this.dispose();
        
    }
    void NewStudentActionPerformed(ActionEvent e){
        NewStudent ob = new NewStudent();
        ob.setVisible(true);
        this.dispose();
        
    }
    void ReturnBookActionPerformed(ActionEvent e){
        ReturnBook ob = new ReturnBook();
        ob.setVisible(true);
        this.dispose();
        
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LibaryManagmentSystem();
            }
        });
    }
}
 