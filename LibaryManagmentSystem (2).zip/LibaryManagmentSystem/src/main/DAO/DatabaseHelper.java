/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 44794
 */
import java.sql.*;
public class DatabaseHelper {
    public static Connection getConnection(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            
           Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/?user=root","root","1234");
           System.err.println("Connection done");
            return con;
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Connection error");
}
        return null;
    }
}
